# Atividade Paralela 1 – Godot 4

Projeto atualizado com HUD de moedas e duas fases.

## Como executar
1. Extraia o arquivo ZIP.
2. Abra o Godot 4 e clique em **Importar**.
3. Selecione a pasta extraída e abra `project.godot`.
4. Execute com **F6/F5**.

## Controles
- Jogador 1: **A/D** para mover e **W** para pular.
- Jogador 2: **setas esquerda/direita** para mover e **seta para cima** para pular.

## Objetivo
- Colete 5 moedas em cada fase para desbloquear o portal.
- Entre no portal para avançar da fase 1 para a fase 2.
- Na fase 2, quem entrar primeiro no portal depois de coletar as 5 moedas vence.

O HUD mostra a quantidade de moedas coletadas e a fase atual. Os cenários e personagens são desenhados pelo próprio Godot, sem precisar de imagens externas.
