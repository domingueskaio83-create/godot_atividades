extends Node2D

const Player = preload("res://player.gd")
const Platform = preload("res://platform.gd")
const Portal = preload("res://portal.gd")
const Coin = preload("res://coin.gd")

const COINS_TO_UNLOCK := 5
var phase := 1
var coins_collected := 0
var game_over := false
var message_label: Label
var hud_label: Label
var phase_label: Label
var debug_label: Label
var portal: Area2D
var players: Array[CharacterBody2D] = []
var level_nodes: Array[Node] = []

func _ready() -> void:
	_create_background()
	_create_hud()
	_create_title()
	_create_instructions()
	_create_debug_area()
	_start_phase()

func _create_background() -> void:
	var bg := ColorRect.new()
	bg.position = Vector2.ZERO
	bg.size = Vector2(800, 600)
	bg.color = Color(0.12, 0.14, 0.18)
	bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(bg)
	move_child(bg, 0)

func _create_title() -> void:
	var title := Label.new()
	title.position = Vector2(20, 12)
	title.size = Vector2(760, 32)
	title.text = "DISPUTA PELO PORTAL"
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.add_theme_font_size_override("font_size", 24)
	add_child(title)

func _create_hud() -> void:
	hud_label = Label.new()
	hud_label.position = Vector2(18, 48)
	hud_label.size = Vector2(250, 28)
	hud_label.add_theme_font_size_override("font_size", 18)
	add_child(hud_label)
	phase_label = Label.new()
	phase_label.position = Vector2(600, 48)
	phase_label.size = Vector2(180, 28)
	phase_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	phase_label.add_theme_font_size_override("font_size", 18)
	add_child(phase_label)
	_update_hud()

func _create_instructions() -> void:
	var label := Label.new()
	label.position = Vector2(18, 78)
	label.size = Vector2(765, 42)
	label.text = "P1: A / D + W para pular     |     P2: ← / → + ↑ para pular"
	label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	label.add_theme_font_size_override("font_size", 14)
	add_child(label)

	message_label = Label.new()
	message_label.position = Vector2(150, 235)
	message_label.size = Vector2(500, 100)
	message_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	message_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	message_label.add_theme_font_size_override("font_size", 25)
	message_label.visible = false
	add_child(message_label)

func _create_debug_area() -> void:
	debug_label = Label.new()
	debug_label.position = Vector2(18, 580)
	debug_label.size = Vector2(764, 20)
	debug_label.text = "Objetivo: colete 5 moedas para liberar o portal."
	debug_label.add_theme_font_size_override("font_size", 12)
	add_child(debug_label)

func _update_hud() -> void:
	hud_label.text = "MOEDAS: %d / %d" % [coins_collected, COINS_TO_UNLOCK]
	phase_label.text = "FASE %d / 2" % phase

func _start_phase() -> void:
	coins_collected = 0
	_update_hud()
	for node in level_nodes:
		if is_instance_valid(node):
			node.queue_free()
	level_nodes.clear()
	players.clear()

	var positions: Array[Vector2]
	var sizes: Array[Vector2]
	var coin_positions: Array[Vector2]

	if phase == 1:
		positions = [Vector2(400, 560), Vector2(180, 485), Vector2(390, 485), Vector2(620, 485), Vector2(280, 420), Vector2(510, 420), Vector2(160, 360), Vector2(370, 350), Vector2(620, 355), Vector2(270, 285), Vector2(500, 280), Vector2(150, 220), Vector2(350, 205), Vector2(590, 210), Vector2(250, 145), Vector2(460, 130), Vector2(650, 145)]
		coin_positions = [Vector2(180, 455), Vector2(390, 455), Vector2(620, 455), Vector2(280, 390), Vector2(510, 390), Vector2(160, 330), Vector2(370, 320), Vector2(620, 325), Vector2(270, 255), Vector2(500, 250)]
	else:
		positions = [Vector2(400, 560), Vector2(120, 490), Vector2(350, 475), Vector2(650, 490), Vector2(220, 405), Vector2(500, 390), Vector2(100, 320), Vector2(350, 300), Vector2(680, 315), Vector2(210, 225), Vector2(480, 205), Vector2(650, 125), Vector2(390, 115)]
		coin_positions = [Vector2(120, 460), Vector2(350, 445), Vector2(650, 460), Vector2(220, 375), Vector2(500, 360), Vector2(100, 290), Vector2(350, 270), Vector2(680, 285), Vector2(210, 195), Vector2(480, 175)]

	for i in positions.size():
		var platform := Platform.new()
		platform.position = positions[i]
		platform.size = Vector2(700, 25) if i == 0 else Vector2(125, 18)
		add_child(platform)
		level_nodes.append(platform)

	for coin_position in coin_positions:
		var coin := Coin.new()
		coin.position = coin_position
		coin.collected.connect(_on_coin_collected)
		add_child(coin)
		level_nodes.append(coin)

	var p1 := Player.new()
	p1.name = "Player1"
	p1.player_name = "Player 1"
	p1.color = Color(0.95, 0.25, 0.22)
	p1.left_action = "p1_left"
	p1.right_action = "p1_right"
	p1.jump_action = "p1_jump"
	p1.position = Vector2(100, 510)
	add_child(p1)
	players.append(p1)
	level_nodes.append(p1)

	var p2 := Player.new()
	p2.name = "Player2"
	p2.player_name = "Player 2"
	p2.color = Color(0.18, 0.55, 1.0)
	p2.left_action = "p2_left"
	p2.right_action = "p2_right"
	p2.jump_action = "p2_jump"
	p2.position = Vector2(700, 510)
	add_child(p2)
	players.append(p2)
	level_nodes.append(p2)

	portal = Portal.new()
	portal.name = "Portal"
	portal.position = Vector2(400, 78)
	portal.player_reached.connect(_on_portal_reached)
	add_child(portal)
	level_nodes.append(portal)
	portal.set_active(false)
	debug_label.text = "Fase %d: colete %d moedas para liberar o portal!" % [phase, COINS_TO_UNLOCK]

func _on_coin_collected() -> void:
	if game_over:
		return
	coins_collected += 1
	_update_hud()
	if coins_collected >= COINS_TO_UNLOCK and is_instance_valid(portal):
		portal.set_active(true)
		debug_label.text = "Portal liberado! Corra até ele!"

func _on_portal_reached(winner: String) -> void:
	if game_over:
		return
	if coins_collected < COINS_TO_UNLOCK:
		return
	if phase == 1:
		phase = 2
		message_label.text = "FASE 1 CONCLUÍDA!\nPreparado para a próxima?"
		message_label.visible = true
		debug_label.text = winner + " encontrou o portal!"
		await get_tree().create_timer(1.8).timeout
		message_label.visible = false
		_start_phase()
	else:
		game_over = true
		print(winner + " venceu o jogo!")
		message_label.text = winner.to_upper() + " VENCEU!\nParabéns!"
		message_label.visible = true
		debug_label.text = winner + " venceu as duas fases!"
		await get_tree().create_timer(3.0).timeout
		get_tree().reload_current_scene()
