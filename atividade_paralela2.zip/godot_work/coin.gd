extends Area2D

signal collected

var taken := false

func _ready() -> void:
	var shape := CollisionShape2D.new()
	var circle := CircleShape2D.new()
	circle.radius = 13
	shape.shape = circle
	add_child(shape)
	body_entered.connect(_on_body_entered)
	queue_redraw()

func _on_body_entered(body: Node2D) -> void:
	if taken:
		return
	if body is CharacterBody2D:
		taken = true
		collected.emit()
		queue_free()

func _draw() -> void:
	draw_circle(Vector2.ZERO, 12, Color(1.0, 0.78, 0.08))
	draw_circle(Vector2.ZERO, 7, Color(1.0, 0.92, 0.35))
	draw_arc(Vector2.ZERO, 10, 0, TAU, 32, Color(1.0, 0.98, 0.7), 2.0)
