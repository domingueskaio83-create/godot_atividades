extends Area2D

signal player_reached(player_name: String)

var portal_color := Color(0.1, 0.65, 1.0)
var active := false

func _ready() -> void:
	var shape := CollisionShape2D.new()
	var circle := CircleShape2D.new()
	circle.radius = 35
	shape.shape = circle
	add_child(shape)
	body_entered.connect(_on_body_entered)
	queue_redraw()

func set_active(value: bool) -> void:
	active = value
	queue_redraw()

func _on_body_entered(body: Node2D) -> void:
	if not active:
		return
	if body.has_method("get") and body.get("player_name") != null:
		active = false
		player_reached.emit(str(body.player_name))

func _draw() -> void:
	var glow := Color(0.02, 0.08, 0.18, 0.9) if active else Color(0.08, 0.08, 0.10, 0.9)
	var ring := portal_color if active else Color(0.35, 0.35, 0.4)
	draw_circle(Vector2.ZERO, 38, glow)
	draw_arc(Vector2.ZERO, 34, 0, TAU, 64, ring, 8.0)
	draw_arc(Vector2.ZERO, 25, 0, TAU, 64, ring.lightened(0.2), 5.0)
	draw_circle(Vector2.ZERO, 16, glow)
